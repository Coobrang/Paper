document.addEventListener("DOMContentLoaded", function() {
    var mobileNavButton = document.getElementById("mobile-nav-button");
    var mobileNav = document.getElementById("mobile-nav");

    mobileNavButton.addEventListener("click", function() {
        mobileNav.classList.toggle("open");
    });
});